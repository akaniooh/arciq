"use client";

import { createConfig, http } from "wagmi";
import { hardhat } from "wagmi/chains";
import { defineChain } from "viem";
import { injected, coinbaseWallet } from "wagmi/connectors";
import { QueryClient } from "@tanstack/react-query";

export const arcTestnet = defineChain({
  id: 5042002,
  name: "Arc Testnet",
  nativeCurrency: {
    name: "USD Coin",
    symbol: "USDC",
    decimals: 18,
  },
  rpcUrls: {
    default: {
      http: ["https://rpc.testnet.arc.network"],
      webSocket: ["wss://rpc.testnet.arc.network"],
    },
  },
  blockExplorers: {
    default: {
      name: "ArcScan",
      url: "https://testnet.arcscan.app",
    },
  },
  testnet: true,
});

export const queryClient = new QueryClient();

export const wagmiConfig = createConfig({
  chains: [arcTestnet, hardhat],
  connectors: [
    injected(),
    coinbaseWallet({ appName: "ArcIQ" }),
  ],
  transports: {
    [arcTestnet.id]: http("https://rpc.testnet.arc.network"),
    [hardhat.id]: http("http://127.0.0.1:8545"),
  },
});

declare module "wagmi" {
  interface Register {
    config: typeof wagmiConfig;
  }
}
